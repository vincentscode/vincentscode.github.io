# coding=utf-8
# /usr/bin/python
import random
try:
	from _thread import start_new_thread
except:
	from thread import start_new_thread
import requests
import json

from kivy.app import App
from kivy.core.window import Window
from kivy.uix.label import Label
from kivy.uix.widget import Widget
from kivy.uix.button import Button
from kivy.graphics import Color, Ellipse, Line
from kivy.clock import Clock
from kivy.app import App

class MyPaintWidget(Widget):
	alphabet = list('''abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ßäöüÄÖÜ-_;,:+*~"!%&/€@=()<>."''')
	url = 'https://handwritingcollector.firebaseio.com'

	current_char = ""

	drawingLines = []

	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		Clock.schedule_once(self.update_char)

	def update_char(self, *_):
		self.current_char = random.choice(self.alphabet)
		App.get_running_app().lbl.text = 'SCHREIBE: ' + self.current_char
		self.clear_canvas()

	def clear_canvas(self, *_):
		self.drawingLines = []
		self.canvas.clear()

	def on_touch_down(self, touch):
		with self.canvas:
			Color(1, 1, 1, 1)
			self.drawingLines.append(Line(points=[touch.x, touch.y], width=2))

	def on_touch_move(self, touch):
		self.drawingLines[-1].points += [touch.x, touch.y]

	def on_confirm(self, *_):
		def do(c, l):
			result = eval(requests.get(self.url + '/' + c + ".json", None).text)
			sb = ""
			for a in l:
				for i in range(0, len(a.points), 2):
					sb += "("
					sb += str(a.points[i])
					sb += "|"
					sb += str(a.points[i+1])
					sb += "), "
				sb += "#"
			r = requests.patch(self.url +'/' + c + '.json', data='{"%s": "%s"}' % (str(len(result)), sb))
			print(r, r.text)
		start_new_thread(do, (self.current_char, self.drawingLines))
		self.update_char()	


class MyPaintApp(App):
	def build(self):
		self.par = Widget()
		pw = MyPaintWidget()
		self.par.add_widget(pw)
		self.lbl = Label(text='', pos=(Window.width / 2 - 50, Window.height - 100), color=(1, 1, 1, 1))
		self.par.add_widget(self.lbl)

		self.par.ok_button = Button(text='Senden', pos=(Window.width - 100, Window.height - 100), size=(100, 100))
		self.par.ok_button.bind(on_press=pw.on_confirm)
		self.par.add_widget(self.par.ok_button)

		self.par.clear_button = Button(text='Leeren', pos=(Window.width - 100, Window.height - 220), size=(100, 100))
		self.par.clear_button.bind(on_press=pw.clear_canvas)
		self.par.add_widget(self.par.clear_button)
		return self.par

if __name__ == '__main__':
	MyPaintApp().run()
